public class HelloWorld
{
	public static void main(String[] s)
	{
		System.out.println("Hello World");
		for(int i=0; i<=10; i++)
		{
			System.out.println(i);
		}
	
	}
}
